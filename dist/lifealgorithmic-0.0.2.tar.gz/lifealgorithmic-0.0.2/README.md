# Tools For My Classes

This is a hodgepodge of tools I use to automate classes. 

### lifealgorithmic 

Infrastructure that's designed to be used as a Python package. 

`armor.py` - Protects the source of a Python script my making it an executable C program. 
`aws-roster` - Generate Cloud9 accounts from a JSON roster file. 
`canvas.py` - Helpers for working with Canvas ZIP files. 
`decode-cfm` - Decoder for my embedded confirmation numbers. 

## Under Construction 

This code is actively developed. 